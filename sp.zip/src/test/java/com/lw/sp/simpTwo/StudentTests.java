package com.lw.sp.simpTwo;

import com.lw.sp.RedisUtil;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.*;
import java.util.List;
import java.util.Map;


public class StudentTests {

    @Test
    public void one(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application-one.xml");
        DataSource dataSource = (DataSource) applicationContext.getBean("datasource");
        Connection  con = null;
        Statement stm = null;
        try {
            con = dataSource.getConnection();
            stm = con.createStatement();
            String sql = "select name from student";
            ResultSet rs = stm.executeQuery(sql);

            while (rs.next()) {
                String name = rs.getString("name");
                System.out.println("姓名：" + name);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void two(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application-jdbc-template.xml");
        JdbcTemplate jdbcTemplate = (JdbcTemplate)applicationContext.getBean("jdbcTemplate");
        String sql = "select name from student";
        List<Map<String,Object>> list = jdbcTemplate.queryForList(sql);
        for(Map<String,Object> p: list){
            for(Map.Entry<String,Object> entry:p.entrySet()){
                System.out.println(entry.getKey());
                System.out.println(entry.getValue());
            }
        }
    }

    @Test
    public void three(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application-jdbc-template.xml");
        RedisTemplate redisTemplate = (RedisTemplate) applicationContext.getBean("redisTemplate");
        redisTemplate.opsForValue().set("liu","wei");
        System.out.println(redisTemplate.opsForValue().get("liu"));
    }

    @Test
    public void four(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application-jdbc-template.xml");
        RedisUtil redisUtil = (RedisUtil) applicationContext.getBean("redisUtil");
        redisUtil.set("liu","123");
        System.out.println(redisUtil.get("liu"));
    }
}
