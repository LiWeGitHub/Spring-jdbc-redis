package com.lw.sp.ser;

import java.io.IOException;

public interface Serializer {
    String name();

    byte[] serialize(Object var1) throws IOException;

    Object deserialize(byte[] var1) throws IOException;
}