package com.lw.sp.ser;



import de.ruedigermoeller.serialization.FSTObjectInput;
import de.ruedigermoeller.serialization.FSTObjectOutput;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class FSTSerializer implements Serializer {
    public FSTSerializer() {
    }

    public String name() {
        return "fst";
    }

    public byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream out = null;
        FSTObjectOutput fout = null;

        byte[] var4;
        try {
            out = new ByteArrayOutputStream();
            fout = new FSTObjectOutput(out);
            fout.writeObject(obj);
            var4 = out.toByteArray();
        } finally {
            if (fout != null) {
                try {
                    fout.close();
                } catch (IOException var11) {
                }
            }

        }

        return var4;
    }

    public Object deserialize(byte[] bytes) throws IOException {
        if (bytes != null && bytes.length != 0) {
            FSTObjectInput in = null;

            Object var3;
            try {
                in = new FSTObjectInput(new ByteArrayInputStream(bytes));
                var3 = in.readObject();
            } catch (ClassNotFoundException var12) {
                throw new IOException(var12);
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException var11) {
                    }
                }

            }

            return var3;
        } else {
            return null;
        }
    }
}
