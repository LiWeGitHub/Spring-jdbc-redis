package com.lw.sp;

import com.lw.sp.ser.FSTSerializer;
import com.lw.sp.ser.JavaSerializer;
import com.lw.sp.ser.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.*;
import redis.clients.jedis.params.geo.GeoRadiusParam;

import java.util.*;

public class RedisUtil {
    private static final Logger logger = LoggerFactory.getLogger(RedisUtil.class);
    private JedisPool jedisPool;
    private Serializer serializer;
    private Integer databaseDefaultIndex;
    private Integer databaseIndex;
    public static final String R_OK = "OK";
    public static final Long R_1L = 1L;

    public RedisUtil(JedisPool pool, String serializer) throws Exception {
        this(pool, serializer, 0);
    }

    public RedisUtil(JedisPool pool, String serializer, Integer databaseIndex) throws Exception {
        this.databaseDefaultIndex = 0;
        this.databaseIndex = 0;
        if (pool == null) {
            String msg = "RedisUtil jedisPool is null, please check the config file.";
            logger.error(msg);
            throw new Exception(msg);
        } else {
            this.jedisPool = pool;
            if (serializer != null && !serializer.isEmpty()) {
                byte var5 = -1;
                switch(serializer.hashCode()) {
                    case 101703:
                        if (serializer.equals("fst")) {
                            var5 = 1;
                        }
                        break;
                    case 3254818:
                        if (serializer.equals("java")) {
                            var5 = 0;
                        }
                }

                switch(var5) {
                    case 0:
                        this.serializer = new JavaSerializer();
                        break;
                    case 1:
                        this.serializer = new FSTSerializer();
                        break;
                    default:
                        this.serializer = new JavaSerializer();
                }

                logger.info("RedisUtil serializer is " + this.serializer.name());
            } else {
                this.serializer = new JavaSerializer();
                logger.warn("RedisUtil constructor param serializer is not set.");
            }

            if (databaseIndex != null) {
                this.databaseIndex = databaseIndex;
            }

        }
    }

    public Jedis getJedis() {
        Jedis jedis = this.jedisPool.getResource();
        if (!this.databaseDefaultIndex.equals(this.databaseIndex)) {
            jedis.select(this.databaseIndex);
        }

        return jedis;
    }

    public void close(Jedis jedis) {
        if (jedis != null) {
            try {
                jedis.close();
            } catch (Exception var3) {
                logger.error("释放redis连接异常", var3);
            }
        }

    }

    public static boolean expect(List<Object> results, Object... expects) {
        try {
            if (results != null && expects != null && results.size() == expects.length) {
                for(int i = 0; i < expects.length; ++i) {
                    Object result = results.get(i);
                    if (result == null || !result.equals(expects[i])) {
                        return false;
                    }
                }

                return true;
            }
        } catch (Exception var4) {
            logger.error("对比失败:" + results + " @ " + Arrays.toString(expects), var4);
        }

        return false;
    }

    public long del(String key) {
        Jedis jedis = null;

        long var4;
        try {
            jedis = this.getJedis();
            long var3 = jedis.del(key.getBytes());
            return var3;
        } catch (Exception var9) {
            logger.error("redis 异常", var9);
            var4 = -1L;
        } finally {
            this.close(jedis);
        }

        return var4;
    }

    public long del(String[] keys) {
        Jedis jedis = null;

        try {
            jedis = this.getJedis();
            long var3 = jedis.del(keys);
            return var3;
        } catch (Exception var8) {
            logger.error("redis 异常", var8);
        } finally {
            this.close(jedis);
        }

        return -1L;
    }

    /** @deprecated */
    @Deprecated
    public Boolean check(String key) {
        return this.exists(key);
    }

    public Boolean exists(String key) {
        Jedis jedis = null;

        Boolean var4;
        try {
            jedis = this.getJedis();
            Boolean var3 = jedis.exists(key);
            return var3;
        } catch (Exception var8) {
            logger.error("redis 异常", var8);
            var4 = false;
        } finally {
            this.close(jedis);
        }

        return var4;
    }

    public boolean set(String key, String value) {
        Jedis jedis = null;

        boolean var5;
        try {
            jedis = this.getJedis();
            jedis.set(key, value);
            boolean var4 = true;
            return var4;
        } catch (Exception var9) {
            logger.error("redis String 保存字符串异常", var9);
            var5 = false;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public String setObject(String key, Object value) {
        Jedis jedis = null;

        try {
            jedis = this.getJedis();
            String var4 = jedis.set(key.getBytes(), this.serializer.serialize(value));
            return var4;
        } catch (Exception var8) {
            logger.error("redis String 保存对象异常", var8);
        } finally {
            this.close(jedis);
        }

        return null;
    }

    public String get(String key) {
        Jedis jedis = null;

        Object var4;
        try {
            jedis = this.getJedis();
            String var3 = jedis.get(key);
            return var3;
        } catch (Exception var8) {
            logger.error("redis String 获取字符串异常", var8);
            var4 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var4;
    }

    public Object getObject(String key) {
        Jedis jedis = null;

        Object var4;
        try {
            jedis = this.getJedis();
            byte[] b = jedis.get(key.getBytes());
            var4 = this.serializer.deserialize(b);
            return var4;
        } catch (Exception var8) {
            logger.error("redis String 获取对象异常", var8);
            var4 = null;
        } finally {
            this.close(jedis);
        }

        return var4;
    }

    public String getRange(String key, long startOffset, long endOffset) {
        Jedis jedis = null;

        Object var8;
        try {
            jedis = this.getJedis();
            String var7 = jedis.getrange(key, startOffset, endOffset);
            return var7;
        } catch (Exception var12) {
            logger.error("redis String getRange异常", var12);
            var8 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var8;
    }

    public String getSet(String key, String newValue) {
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            String var4 = jedis.getSet(key, newValue);
            return var4;
        } catch (Exception var9) {
            logger.error("redis String getSet异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var5;
    }

    public boolean mset(String... keyValues) {
        Jedis jedis = null;

        boolean var4;
        try {
            jedis = this.getJedis();
            jedis.mset(keyValues);
            boolean var3 = true;
            return var3;
        } catch (Exception var8) {
            logger.error("redis String mset异常", var8);
            var4 = false;
        } finally {
            this.close(jedis);
        }

        return var4;
    }

    public List<String> mget(String... keys) {
        Jedis jedis = null;

        Object var4;
        try {
            jedis = this.getJedis();
            List var3 = jedis.mget(keys);
            return var3;
        } catch (Exception var8) {
            logger.error("redis String mget异常", var8);
            var4 = null;
        } finally {
            this.close(jedis);
        }

        return (List)var4;
    }

    public boolean hset(String key, String field, String value) {
        Jedis jedis = null;

        boolean var6;
        try {
            jedis = this.getJedis();
            jedis.hset(key, field, value);
            boolean var5 = true;
            return var5;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var6 = false;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public long hsetnx(String key, String field, String value) {
        Jedis jedis = null;

        long var6;
        try {
            jedis = this.getJedis();
            long var5 = jedis.hsetnx(key, field, value);
            return var5;
        } catch (Exception var11) {
            logger.error("redis 异常", var11);
            var6 = -1L;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public boolean hmset(String key, Map<String, String> hash) {
        Jedis jedis = null;

        boolean var5;
        try {
            jedis = this.getJedis();
            jedis.hmset(key, hash);
            boolean var4 = true;
            return var4;
        } catch (Exception var9) {
            logger.error("redis 异常", var9);
            var5 = false;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public String hgetStr(String key, String field) {
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            String var4 = jedis.hget(key, field);
            return var4;
        } catch (Exception var9) {
            logger.error("redis 异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var5;
    }

    public Map<String, String> hgetall(String key) {
        Jedis jedis = null;

        try {
            jedis = this.getJedis();
            Map var3 = jedis.hgetAll(key);
            return var3;
        } catch (Exception var7) {
            logger.error("redis 异常", var7);
        } finally {
            this.close(jedis);
        }

        return null;
    }

    public Set<String> hkeys(String key) {
        Jedis jedis = null;

        Object var4;
        try {
            jedis = this.getJedis();
            Set var3 = jedis.hkeys(key);
            return var3;
        } catch (Exception var8) {
            logger.error("redis 异常", var8);
            var4 = null;
        } finally {
            this.close(jedis);
        }

        return (Set)var4;
    }

    public List<String> hvals(String key) {
        Jedis jedis = null;

        Object var4;
        try {
            jedis = this.getJedis();
            List var3 = jedis.hvals(key);
            return var3;
        } catch (Exception var8) {
            logger.error("redis 异常", var8);
            var4 = null;
        } finally {
            this.close(jedis);
        }

        return (List)var4;
    }

    public List<String> hmget(String key, String... fields) {
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            List var4 = jedis.hmget(key, fields);
            return var4;
        } catch (Exception var9) {
            logger.error("redis 异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (List)var5;
    }

    public long hlen(String key) {
        Jedis jedis = null;

        long var4;
        try {
            jedis = this.getJedis();
            long var3 = jedis.hlen(key);
            return var3;
        } catch (Exception var9) {
            logger.error("redis 异常", var9);
            var4 = 0L;
        } finally {
            this.close(jedis);
        }

        return var4;
    }

    public void hdel(String key, String field) {
        Jedis jedis = null;

        try {
            jedis = this.jedisPool.getResource();
            jedis.hdel(key, new String[]{field});
        } catch (Exception var8) {
            logger.error("redis异常", var8);
        } finally {
            this.close(jedis);
        }

    }

    public long hdel(String key, String... fields) {
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            long var4 = jedis.hdel(key, fields);
            return var4;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    /** @deprecated */
    @Deprecated
    public Boolean hcheck(String key, String field) {
        return this.hexists(key, field);
    }

    public Boolean hexists(String key, String field) {
        Jedis jedis = null;

        Boolean var5;
        try {
            jedis = this.getJedis();
            Boolean var4 = jedis.hexists(key.getBytes(), field.getBytes());
            return var4;
        } catch (Exception var9) {
            logger.error("redis 异常", var9);
            var5 = false;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public Long hincrby(String key, String field, Long increment) {
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            Long var5 = jedis.hincrBy(key, field, increment);
            return var5;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Long)var6;
    }

    public Double hincrby(String key, String field, Double increment) {
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            Double var5 = jedis.hincrByFloat(key, field, increment);
            return var5;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Double)var6;
    }

    public long lpush(String key, String... value) {
        boolean success = true;
        Jedis jedis = null;

        long var6;
        try {
            jedis = this.getJedis();
            long count = jedis.lpush(key, value);
            long var7 = count;
            return var7;
        } catch (Exception var12) {
            success = false;
            logger.error("redis 异常", var12);
            var6 = -1L;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public long rpush(String key, String... values) {
        boolean success = true;
        Jedis jedis = null;

        long var6;
        try {
            jedis = this.getJedis();
            long count = jedis.rpush(key, values);
            long var7 = count;
            return var7;
        } catch (Exception var12) {
            success = false;
            logger.error("redis 异常", var12);
            var6 = -1L;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public String lpop(String key) {
        boolean success = true;
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            String var4 = jedis.lpop(key);
            return var4;
        } catch (Exception var9) {
            success = false;
            logger.error("redis 异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var5;
    }

    public String rpop(String key) {
        boolean success = true;
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            String var4 = jedis.rpop(key);
            return var4;
        } catch (Exception var9) {
            success = false;
            logger.error("redis 异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var5;
    }

    public List<String> brpop(String key, int timeout) {
        List<String> list = null;
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            list = jedis.brpop(timeout, key);
            return list;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (List)var6;
    }

    public List<String> blpop(String key, int timeout) {
        List<String> list = null;
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            list = jedis.blpop(timeout, key);
            return list;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (List)var6;
    }

    public List<String> lrange(String key, long start, long end) {
        boolean success = true;
        Jedis jedis = null;

        Object var9;
        try {
            jedis = this.getJedis();
            List var8 = jedis.lrange(key, start, end);
            return var8;
        } catch (Exception var13) {
            success = false;
            logger.error("redis 异常", var13);
            var9 = null;
        } finally {
            this.close(jedis);
        }

        return (List)var9;
    }

    public long lrem(String key, String value) {
        boolean success = true;
        Jedis jedis = null;

        long var6;
        try {
            jedis = this.getJedis();
            long var5 = jedis.lrem(key, 0L, value);
            return var5;
        } catch (Exception var11) {
            success = false;
            logger.error("redis 异常", var11);
            var6 = -1L;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public long llen(String key) {
        boolean success = true;
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            long var4 = jedis.llen(key);
            return var4;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public long zadd(String key, double score, Object member) {
        boolean success = true;
        Jedis jedis = null;

        long var8;
        try {
            jedis = this.getJedis();
            long var7;
            if (!(member instanceof String)) {
                var7 = jedis.zadd(key.getBytes(), score, this.serializer.serialize(member));
                return var7;
            }

            var7 = jedis.zadd(key, score, (String)member);
            return var7;
        } catch (Exception var13) {
            success = false;
            logger.error("redis 异常", var13);
            var8 = -1L;
        } finally {
            this.close(jedis);
        }

        return var8;
    }

    public long zadd(String key, double score, String member) {
        boolean success = true;
        Jedis jedis = null;

        long var8;
        try {
            jedis = this.getJedis();
            long var7 = jedis.zadd(key, score, member);
            return var7;
        } catch (Exception var13) {
            success = false;
            logger.error("redis 异常", var13);
            var8 = -1L;
        } finally {
            this.close(jedis);
        }

        return var8;
    }

    public long zadd(String key, Map<String, Double> scoreMembers) {
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            long var4 = jedis.zadd(key, scoreMembers);
            return var4;
        } catch (Exception var10) {
            logger.error("redis 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public long zrem(String key, String member) {
        boolean success = true;
        Jedis jedis = null;

        long var6;
        try {
            jedis = this.getJedis();
            long var5 = jedis.zrem(key, new String[]{member});
            return var5;
        } catch (Exception var11) {
            success = false;
            logger.error("redis 异常", var11);
            var6 = -1L;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public long zcard(String key) {
        boolean success = true;
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            long var4 = jedis.zcard(key);
            return var4;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public Double zscore(String key, String member) {
        boolean success = true;
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            Double var5 = jedis.zscore(key, member);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Double)var6;
    }

    public Long zrank(String key, String member) {
        boolean success = true;
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            Long var5 = jedis.zrank(key, member);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Long)var6;
    }

    public Long zrevrank(String key, String member) {
        boolean success = true;
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            Long var5 = jedis.zrevrank(key, member);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Long)var6;
    }

    public Long sdiffstore(String dstkey, String key1, String key2) {
        boolean success = true;
        Jedis jedis = null;

        Object var7;
        try {
            jedis = this.getJedis();
            Long var6 = jedis.sdiffstore(dstkey, new String[]{key1, key2});
            return var6;
        } catch (Exception var11) {
            success = false;
            logger.error("redis 异常", var11);
            var7 = null;
        } finally {
            this.close(jedis);
        }

        return (Long)var7;
    }

    public Set<Object> zrangeRetObject(String key, long start, long stop) {
        boolean success = true;
        Jedis jedis = null;

        HashSet rets;
        try {
            jedis = this.getJedis();
            Set<byte[]> values = jedis.zrange(key.getBytes(), start, stop);
            rets = new HashSet();
            Iterator var10 = values.iterator();

            while(var10.hasNext()) {
                byte[] v = (byte[])var10.next();
                rets.add(this.serializer.deserialize(v));
            }

            HashSet var17 = rets;
            return var17;
        } catch (Exception var15) {
            success = false;
            logger.error("redis 异常", var15);
            rets = null;
        } finally {
            this.close(jedis);
        }

        return rets;
    }

    public Set<String> zrange(String key, long start, long stop) {
        boolean success = true;
        Jedis jedis = null;

        Object var9;
        try {
            jedis = this.getJedis();
            Set var8 = jedis.zrange(key, start, stop);
            return var8;
        } catch (Exception var13) {
            success = false;
            logger.error("redis 异常", var13);
            var9 = null;
        } finally {
            this.close(jedis);
        }

        return (Set)var9;
    }

    public Set<String> zrevrange(String key, long start, long stop) {
        boolean success = true;
        Jedis jedis = null;

        Object var9;
        try {
            jedis = this.getJedis();
            Set var8 = jedis.zrevrange(key, start, stop);
            return var8;
        } catch (Exception var13) {
            success = false;
            logger.error("redis 异常", var13);
            var9 = null;
        } finally {
            this.close(jedis);
        }

        return (Set)var9;
    }

    public Double zincrby(String key, double score, String member) {
        boolean success = true;
        Jedis jedis = null;

        Object var8;
        try {
            jedis = this.getJedis();
            Double var7 = jedis.zincrby(key, score, member);
            return var7;
        } catch (Exception var12) {
            success = false;
            logger.error("redis 异常", var12);
            var8 = null;
        } finally {
            this.close(jedis);
        }

        return (Double)var8;
    }

    public long incr(String key) {
        boolean success = true;
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            long var4 = jedis.incr(key);
            return var4;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public long currentIncr(String key) {
        boolean success = true;
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            String current = jedis.get(key);
            if (current == null) {
                var5 = -1L;
                return var5;
            }

            var5 = new Long(current);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public long expire(String key, int seconds) {
        boolean success = true;
        Jedis jedis = null;

        try {
            jedis = this.getJedis();
            long var5 = jedis.expire(key, seconds);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
        } finally {
            this.close(jedis);
        }

        return -1L;
    }

    public long expireAt(String key, Date date) {
        boolean success = true;
        Jedis jedis = null;

        try {
            jedis = this.getJedis();
            long var5 = jedis.expireAt(key, date.getTime() / 1000L);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
        } finally {
            this.close(jedis);
        }

        return -1L;
    }

    public long ttl(String key) {
        boolean success = true;
        Jedis jedis = null;

        try {
            jedis = this.getJedis();
            long var4 = jedis.ttl(key);
            return var4;
        } catch (Exception var9) {
            success = false;
            logger.error("redis 异常", var9);
        } finally {
            this.close(jedis);
        }

        return -1L;
    }

    public boolean sadd(String key, String... values) {
        boolean success = true;
        Jedis jedis = null;

        boolean var6;
        try {
            jedis = this.getJedis();
            jedis.sadd(key, values);
            return true;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = false;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public boolean sadd(String key, Object value) {
        boolean success = true;
        Jedis jedis = null;

        boolean var6;
        try {
            jedis = this.getJedis();
            if (value instanceof String) {
                jedis.sadd(key, new String[]{(String)value});
            } else {
                jedis.sadd(key.getBytes(), new byte[][]{this.serializer.serialize(value)});
            }

            return true;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = false;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public boolean srem(String key, String... values) {
        boolean success = true;
        Jedis jedis = null;

        boolean var6;
        try {
            jedis = this.getJedis();
            jedis.srem(key, values);
            return true;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = false;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public Set<String> smembers(String key) {
        boolean success = true;
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            Set var4 = jedis.smembers(key);
            return var4;
        } catch (Exception var9) {
            success = false;
            logger.error("redis 异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (Set)var5;
    }

    public Set<Object> smembersRetObject(String key) {
        boolean success = true;
        Jedis jedis = null;

        HashSet rets;
        try {
            jedis = this.getJedis();
            Set<byte[]> values = jedis.smembers(key.getBytes());
            rets = new HashSet();
            Iterator var6 = values.iterator();

            while(var6.hasNext()) {
                byte[] v = (byte[])var6.next();
                rets.add(this.serializer.deserialize(v));
            }

            HashSet var13 = rets;
            return var13;
        } catch (Exception var11) {
            success = false;
            logger.error("redis 异常", var11);
            rets = null;
        } finally {
            this.close(jedis);
        }

        return rets;
    }

    public String spop(String key) {
        boolean success = true;
        Jedis jedis = null;

        Object var5;
        try {
            jedis = this.getJedis();
            String var4 = jedis.spop(key);
            return var4;
        } catch (Exception var9) {
            success = false;
            logger.error("redis 异常", var9);
            var5 = null;
        } finally {
            this.close(jedis);
        }

        return (String)var5;
    }

    public Set<String> spop(String key, Long count) {
        boolean success = true;
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.getJedis();
            Set var5 = jedis.spop(key, count);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Set)var6;
    }

    public boolean sismember(String key, String member) {
        boolean success = true;
        Jedis jedis = null;

        boolean var6;
        try {
            jedis = this.getJedis();
            boolean var5 = jedis.sismember(key, member);
            return var5;
        } catch (Exception var10) {
            success = false;
            logger.error("redis 异常", var10);
            var6 = false;
        } finally {
            this.close(jedis);
        }

        return var6;
    }

    public long scard(String key) {
        boolean success = true;
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.getJedis();
            long ret = jedis.scard(key.getBytes());
            long var6 = ret;
            return var6;
        } catch (Exception var11) {
            success = false;
            logger.error("redis 异常", var11);
            var5 = 0L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public boolean tryGetDistributedLock(String lockKey, String requestId, int expireTime) {
        boolean success = true;
        Jedis jedis = null;

        boolean var7;
        try {
            jedis = this.jedisPool.getResource();
            String result = jedis.set(lockKey, requestId, "NX", "PX", expireTime);
            if (!"OK".equals(result)) {
                var7 = false;
                return var7;
            }

            var7 = true;
        } catch (Exception var11) {
            success = false;
            var11.printStackTrace();
            return false;
        } finally {
            this.close(jedis);
        }

        return var7;
    }

    public long geoadd(String key, double longitude, double latitude, String member) {
        Jedis jedis = null;

        long var9;
        try {
            jedis = this.jedisPool.getResource();
            long var8 = jedis.geoadd(key, longitude, latitude, member);
            return var8;
        } catch (Exception var14) {
            logger.error("redis  geoadd 异常", var14);
            var9 = -1L;
        } finally {
            this.close(jedis);
        }

        return var9;
    }

    public long geoaddByMap(String key, Map<String, GeoCoordinate> memberCoordinateMap) {
        Jedis jedis = null;

        long var5;
        try {
            jedis = this.jedisPool.getResource();
            long var4 = jedis.geoadd(key, memberCoordinateMap);
            return var4;
        } catch (Exception var10) {
            logger.error("redis  geoaddByMap 异常", var10);
            var5 = -1L;
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public List<GeoCoordinate> geops(String key, List<String> members) {
        Jedis jedis = null;

        ArrayList var5;
        try {
            jedis = this.jedisPool.getResource();
            List var4 = jedis.geopos(key, (String[])members.toArray(new String[members.size()]));
            return var4;
        } catch (Exception var9) {
            logger.error("redis  geops 异常", var9);
            var5 = new ArrayList();
        } finally {
            this.close(jedis);
        }

        return var5;
    }

    public Double geodist(String key, String member1, String member2) {
        Jedis jedis = null;

        Object var6;
        try {
            jedis = this.jedisPool.getResource();
            Double var5 = jedis.geodist(key, member1, member2);
            return var5;
        } catch (Exception var10) {
            logger.error("redis  geodis 异常", var10);
            var6 = null;
        } finally {
            this.close(jedis);
        }

        return (Double)var6;
    }

    public Double geodistWithUnit(String key, String member1, String member2, GeoUnit geoUnit) {
        Jedis jedis = null;

        Object var7;
        try {
            jedis = this.jedisPool.getResource();
            Double var6 = jedis.geodist(key, member1, member2, geoUnit);
            return var6;
        } catch (Exception var11) {
            logger.error("redis  geodisWithUnit 异常", var11);
            var7 = null;
        } finally {
            this.close(jedis);
        }

        return (Double)var7;
    }

    public List<GeoRadiusResponse> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit) {
        Jedis jedis = null;

        ArrayList var11;
        try {
            jedis = this.jedisPool.getResource();
            List var10 = jedis.georadius(key, longitude, latitude, radius, unit);
            return var10;
        } catch (Exception var15) {
            logger.error("redis  georadius 异常", var15);
            var11 = new ArrayList();
        } finally {
            this.close(jedis);
        }

        return var11;
    }

    public List<GeoRadiusResponse> georadiusWithParam(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
        Jedis jedis = null;

        ArrayList var12;
        try {
            jedis = this.jedisPool.getResource();
            List var11 = jedis.georadius(key, longitude, latitude, radius, unit, param);
            return var11;
        } catch (Exception var16) {
            logger.error("redis  georadiusWithParam 异常", var16);
            var12 = new ArrayList();
        } finally {
            this.close(jedis);
        }

        return var12;
    }

    public List<GeoRadiusResponse> georadiusByMember(String key, String member, double radius, GeoUnit unit) {
        Jedis jedis = null;

        ArrayList var8;
        try {
            jedis = this.jedisPool.getResource();
            List var7 = jedis.georadiusByMember(key, member, radius, unit);
            return var7;
        } catch (Exception var12) {
            logger.error("redis  georadiusByMember 异常", var12);
            var8 = new ArrayList();
        } finally {
            this.close(jedis);
        }

        return var8;
    }

    public List<GeoRadiusResponse> georadiusByMemberWithParam(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
        Jedis jedis = null;

        ArrayList var9;
        try {
            jedis = this.jedisPool.getResource();
            List var8 = jedis.georadiusByMember(key, member, radius, unit, param);
            return var8;
        } catch (Exception var13) {
            logger.error("redis  georadiusByMemberWithParam 异常", var13);
            var9 = new ArrayList();
        } finally {
            this.close(jedis);
        }

        return var9;
    }

    public List<String> geohash(String key, List<String> members) {
        Jedis jedis = null;

        ArrayList var5;
        try {
            jedis = this.jedisPool.getResource();
            List var4 = jedis.geohash(key, (String[])members.toArray(new String[members.size()]));
            return var4;
        } catch (Exception var9) {
            logger.error("redis  georadiusByMemberWithParam 异常", var9);
            var5 = new ArrayList();
        } finally {
            this.close(jedis);
        }

        return var5;
    }
}

