package com.lw.sp.simpOne;

import lombok.Data;

import java.io.Serializable;

@Data
public class Student implements Serializable {

    private static final long serialVersionUID = 9093217075491075759L;

    private Integer id;

    private String name;

}
